"use client";

import React, { useState } from "react";

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const generateImage = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setImages([]);

    try {
      const res = await fetch(
        "https://image-gen-ai.onrender.com/generate/stream", // 🔴 change after backend deploy
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt }),
        }
      );
      const data = await res.json();
      setImages(data.images);
    } catch (err) {
      console.error(err);
      alert("Something went wrong!");
    }

    setLoading(false);
  };

  return (
    <main style={{ padding: 20 }}>
      <h1>AI Image Generator</h1>
      <input
        style={{ padding: 10, width: "70%" }}
        type="text"
        placeholder="Enter a prompt..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />
      <button onClick={generateImage} disabled={loading} style={{ marginLeft: 10 }}>
        {loading ? "Generating..." : "Generate"}
      </button>

      <div style={{ marginTop: 20 }}>
        {images.map((src, i) => (
          <img key={i} src={src} alt={`gen-${i}`} width={256} height={256} />
        ))}
      </div>
    </main>
  );
}