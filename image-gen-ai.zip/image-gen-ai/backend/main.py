from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import random

app = FastAPI()

# allow frontend to call backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # for production, replace with your Vercel domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class GenerateRequest(BaseModel):
    prompt: str

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/generate/stream")
def generate(req: GenerateRequest):
    # simulate image URL (later connect real AI model here)
    fake_url = f"https://picsum.photos/seed/{random.randint(1,1000)}/512/512"
    return {"images": [fake_url]}